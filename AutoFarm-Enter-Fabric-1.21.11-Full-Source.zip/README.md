# Auto Farm - Enter (Fabric 1.21.11)

## Features implemented
- Press **Enter** to open/close the menu.
- Toggle Auto Farm and Auto Clicker.
- Auto Clicker CPS slider from 5 to 40.
- Select Diamond, Redstone, Gold, Iron, or Ancient Debris.
- Searches loaded client-world blocks in a 16-block horizontal / 8-block vertical area, aims at the nearest matching ore, and attacks it when within 4.6 blocks.
- A* route planning over walkable feet positions, including simple one-block step-up/down handling, with recalculation when the route becomes blocked.\n- On-screen top-down route trace showing the planned path around nearby obstacles.
- Status readout in the menu.

## Important limitations
This is still a client-side navigation helper, not a perfect bot. A* plans paths through currently loaded walkable space and the HUD shows that path as a top-down route trace; it does not yet solve parkour, water, lava, bridging, doors, or arbitrary multi-block jumps. Servers may prohibit automation. Test in a single-player world first. Auto Clicker holds the vanilla attack key in CPS pulses; game/server behavior may affect the actual rate.

## Build
Use Java 21 and Gradle:
`gradle build`

The jar is created under `build/libs/`.


## Build from Android using GitHub
1. Create a GitHub repository and upload the contents of this ZIP (not the ZIP itself).
2. Open the repository's **Actions** tab.
3. Choose **Build Auto Farm**, press **Run workflow**.
4. Open the completed run and download the `AutoFarm-Enter-Fabric-1.21.11` artifact.
5. Unzip the artifact; the mod `.jar` is inside.
