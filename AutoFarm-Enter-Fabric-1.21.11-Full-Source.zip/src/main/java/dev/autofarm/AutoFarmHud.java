package dev.autofarm;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.BlockPos;

public final class AutoFarmHud {
    private AutoFarmHud() {}

    public static void register() {
        HudRenderCallback.EVENT.register((context, tickCounter) -> render(context));
    }

    private static void render(DrawContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null) return;
        if (!AutoFarmClient.autoFarm && !AutoFarmClient.autoClicker) return;

        int x = 8, y = 8;
        ctx.fill(x - 3, y - 3, x + 154, y + 34, 0x99000000);
        ctx.drawText(mc.textRenderer, "Auto Farm: " + (AutoFarmClient.autoFarm ? "ON" : "OFF"), x, y, 0xFFFFFF, true);
        ctx.drawText(mc.textRenderer, "Clicker: " + (AutoFarmClient.autoClicker ? AutoFarmClient.cps + " CPS" : "OFF"), x, y + 11, 0xFFFFFF, true);
        ctx.drawText(mc.textRenderer, AutoFarmClient.status, x, y + 22, 0xFFFF55, true);

        if (AutoFarmClient.autoFarm && !AutoFarmClient.route.isEmpty()) {
            // A compact top-down route trace: the player is the center and each segment
            // shows the A* path around obstacles. This remains readable even in caves.
            int mx = 88, my = 86, scale = 4, radius = 68;
            ctx.fill(mx - radius, my - radius, mx + radius, my + radius, 0x99000000);
            ctx.drawBorder(mx - radius, my - radius, radius * 2, radius * 2, 0xFF777777);
            ctx.fill(mx - 2, my - 2, mx + 3, my + 3, 0xFF55FF55);
            BlockPos player = mc.player.getBlockPos();
            int prevX = mx, prevY = my;
            int shown = 0;
            for (BlockPos p : AutoFarmClient.route) {
                int px = mx + (p.getX() - player.getX()) * scale;
                int py = my + (p.getZ() - player.getZ()) * scale;
                if (Math.abs(px - mx) > radius - 3 || Math.abs(py - my) > radius - 3) break;
                drawSegment(ctx, prevX, prevY, px, py, 0xFF35D7FF);
                ctx.fill(px - 1, py - 1, px + 2, py + 2, 0xFF35D7FF);
                prevX = px; prevY = py;
                if (++shown > 120) break;
            }
            ctx.drawText(mc.textRenderer, "A* route (top-down)", mx - radius, my + radius + 4, 0xFF35D7FF, true);
        }
    }

    private static void drawSegment(DrawContext ctx, int x1, int y1, int x2, int y2, int color) {
        // Bresenham line rendered as tiny screen-space rectangles.
        int dx = Math.abs(x2 - x1), sx = x1 < x2 ? 1 : -1;
        int dy = -Math.abs(y2 - y1), sy = y1 < y2 ? 1 : -1;
        int err = dx + dy;
        while (true) {
            ctx.fill(x1, y1, x1 + 2, y1 + 2, color);
            if (x1 == x2 && y1 == y2) break;
            int e2 = 2 * err;
            if (e2 >= dy) { err += dy; x1 += sx; }
            if (e2 <= dx) { err += dx; y1 += sy; }
        }
    }
}
