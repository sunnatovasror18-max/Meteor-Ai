package dev.autofarm;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.PriorityQueue;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class AutoFarmClient implements ClientModInitializer {
    public static boolean autoFarm = false;
    public static boolean autoClicker = false;
    public static int cps = 10;
    public static int targetIndex = 0;
    public static BlockPos targetBlock = null;
    public static String status = "Idle";
    public static final String[] TARGETS = {"Diamond", "Redstone", "Gold", "Iron", "Ancient Debris"};
    private static KeyBinding menuKey;
    private static long lastClickNanos = 0;
    private static long lastScanMillis = 0;
    private static int stuckTicks = 0;
    private static Vec3d lastPosition = Vec3d.ZERO;
    public static final List<BlockPos> route = new ArrayList<>();
    private static long lastPathMillis = 0;
    private static BlockPos routeGoal = null;

    private record Node(BlockPos pos, double g, double f) {}

    @Override public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.autofarm_enter.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_ENTER,
                KeyBinding.Category.create("category.autofarm_enter")));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (menuKey.wasPressed()) {
                if (client.currentScreen instanceof AutoFarmScreen) client.setScreen(null);
                else if (client.player != null) client.setScreen(new AutoFarmScreen());
            }
            tick(client);
        });
        AutoFarmHud.register();
    }

    private static void tick(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) return;
        if (client.currentScreen != null) {
            client.options.forwardKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
            client.options.attackKey.setPressed(false);
            return;
        }
        if (autoClicker) {
            long now = System.nanoTime();
            long interval = 1_000_000_000L / Math.max(5, Math.min(40, cps));
            if (now - lastClickNanos >= interval) {
                client.options.attackKey.setPressed(true);
                lastClickNanos = now;
            } else if (now - lastClickNanos >= Math.max(1, interval / 2)) {
                client.options.attackKey.setPressed(false);
            }
        } else {
            client.options.attackKey.setPressed(false);
        }

        if (!autoFarm) {
            status = autoClicker ? "Auto Clicker running" : "Idle";
            return;
        }

        long nowMs = System.currentTimeMillis();
        if (targetBlock == null || nowMs - lastScanMillis > 700 ||
                !isWanted(client.world.getBlockState(targetBlock).getBlock())) {
            targetBlock = findTarget(client);
            lastScanMillis = nowMs;
        }
        if (targetBlock == null) {
            status = "No target nearby";
            route.clear();
            client.options.forwardKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
            return;
        }

        if (routeGoal == null || !routeGoal.equals(targetBlock) || nowMs - lastPathMillis > 1200 || route.isEmpty()) {
            route.clear();
            route.addAll(findPath(client, client.player.getBlockPos(), targetBlock));
            routeGoal = targetBlock.toImmutable();
            lastPathMillis = nowMs;
        }

        Vec3d eyes = client.player.getEyePos();
        Vec3d center = Vec3d.ofCenter(targetBlock);
        double distance = eyes.distanceTo(center);
        aimAt(client, center);
        status = "Target " + TARGETS[targetIndex] + " (" + String.format(java.util.Locale.ROOT, "%.1f", distance) + "m)";

        if (distance <= 4.6) {
            client.options.forwardKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
            client.interactionManager.attackBlock(targetBlock, net.minecraft.util.math.Direction.UP);
            client.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
            BlockState state = client.world.getBlockState(targetBlock);
            if (!isWanted(state.getBlock())) { targetBlock = null; route.clear(); }
        } else {
            // Follow the A* route through walkable feet positions, rather than steering directly
            // into the ore/walls. The route is also drawn in the HUD.
            BlockPos waypoint = route.size() > 1 ? route.get(1) : targetBlock;
            Vec3d waypointCenter = new Vec3d(waypoint.getX() + 0.5, waypoint.getY(), waypoint.getZ() + 0.5);
            double dx = waypointCenter.x - client.player.getX();
            double dz = waypointCenter.z - client.player.getZ();
            double horizontal = Math.sqrt(dx * dx + dz * dz);
            if (horizontal < 0.42 && route.size() > 1) {
                route.remove(0);
                waypoint = route.size() > 1 ? route.get(1) : targetBlock;
                waypointCenter = new Vec3d(waypoint.getX() + 0.5, waypoint.getY(), waypoint.getZ() + 0.5);
                dx = waypointCenter.x - client.player.getX();
                dz = waypointCenter.z - client.player.getZ();
                horizontal = Math.sqrt(dx * dx + dz * dz);
            }
            float yaw = (float)(MathHelper.atan2(dz, dx) * 180.0 / Math.PI) - 90.0F;
            client.player.setYaw(yaw);
            client.options.forwardKey.setPressed(!route.isEmpty());
            client.options.jumpKey.setPressed(!route.isEmpty() && (waypoint.getY() > client.player.getBlockY() || client.player.horizontalCollision));
            if (client.player.getPos().distanceTo(lastPosition) < 0.015) stuckTicks++; else stuckTicks = 0;
            lastPosition = client.player.getPos();
            if (stuckTicks > 70) {
                client.options.forwardKey.setPressed(false);
                client.options.jumpKey.setPressed(false);
                status = "Path blocked — recalculating";
                route.clear();
                routeGoal = null;
                stuckTicks = 0;
            }
        }
    }

    private static BlockPos findTarget(MinecraftClient client) {
        BlockPos origin = client.player.getBlockPos();
        int radius = 16;
        List<BlockPos> found = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int x = -radius; x <= radius; x++) {
            for (int y = -8; y <= 8; y++) {
                for (int z = -radius; z <= radius; z++) {
                    m.set(origin.getX() + x, origin.getY() + y, origin.getZ() + z);
                    if (isWanted(client.world.getBlockState(m).getBlock())) found.add(m.toImmutable());
                }
            }
        }
        return found.stream().min(Comparator.comparingDouble(p -> client.player.squaredDistanceTo(Vec3d.ofCenter(p)))).orElse(null);
    }

    private static List<BlockPos> findPath(MinecraftClient client, BlockPos start, BlockPos ore) {
        // Find a reachable standing position next to the ore, then A* through safe feet positions.
        List<BlockPos> goals = new ArrayList<>();
        for (int[] d : new int[][]{{1,0,0},{-1,0,0},{0,0,1},{0,0,-1},{0,1,0},{0,-1,0}}) {
            BlockPos p = ore.add(d[0], d[1], d[2]);
            if (isStandable(client, p)) goals.add(p);
        }
        if (goals.isEmpty()) return List.of(start);
        Set<BlockPos> goalSet = new HashSet<>(goals);
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble(Node::f));
        Map<BlockPos, Double> cost = new HashMap<>();
        Map<BlockPos, BlockPos> parent = new HashMap<>();
        open.add(new Node(start, 0, heuristic(start, goals)));
        cost.put(start, 0.0);
        Set<BlockPos> closed = new HashSet<>();
        int expanded = 0;
        while (!open.isEmpty() && expanded++ < 4500) {
            Node cur = open.poll();
            if (!closed.add(cur.pos())) continue;
            if (goalSet.contains(cur.pos())) {
                List<BlockPos> result = new ArrayList<>();
                BlockPos at = cur.pos();
                result.add(at);
                while (parent.containsKey(at)) { at = parent.get(at); result.add(at); }
                java.util.Collections.reverse(result);
                return result;
            }
            for (BlockPos next : neighbors(client, cur.pos())) {
                if (closed.contains(next)) continue;
                double step = next.getY() == cur.pos().getY() ? 1.0 : 1.35;
                double tentative = cur.g() + step;
                if (tentative < cost.getOrDefault(next, Double.POSITIVE_INFINITY)) {
                    cost.put(next, tentative);
                    parent.put(next, cur.pos());
                    open.add(new Node(next, tentative, tentative + heuristic(next, goals)));
                }
            }
        }
        return List.of(start);
    }

    private static double heuristic(BlockPos p, List<BlockPos> goals) {
        double best = Double.POSITIVE_INFINITY;
        for (BlockPos g : goals) {
            double d = Math.abs(p.getX()-g.getX()) + Math.abs(p.getZ()-g.getZ()) + 1.4 * Math.abs(p.getY()-g.getY());
            best = Math.min(best, d);
        }
        return best;
    }

    private static List<BlockPos> neighbors(MinecraftClient client, BlockPos p) {
        List<BlockPos> out = new ArrayList<>(12);
        int[][] dirs = {{1,0},{-1,0},{0,1},{0,-1}};
        for (int[] d : dirs) {
            BlockPos same = p.add(d[0],0,d[1]);
            if (isStandable(client, same)) out.add(same);
            else {
                BlockPos up = same.up();
                if (isStandable(client, up) && client.world.getBlockState(same).isSolidBlock(client.world, same)) out.add(up);
            }
            BlockPos down = same.down();
            if (isStandable(client, down) && !client.world.getBlockState(same).isSolidBlock(client.world, same)) out.add(down);
        }
        return out;
    }

    private static boolean isStandable(MinecraftClient client, BlockPos feet) {
        if (client.world == null) return false;
        BlockState feetState = client.world.getBlockState(feet);
        BlockState headState = client.world.getBlockState(feet.up());
        BlockPos floor = feet.down();
        return feetState.getCollisionShape(client.world, feet).isEmpty()
                && headState.getCollisionShape(client.world, feet.up()).isEmpty()
                && !client.world.getBlockState(floor).getCollisionShape(client.world, floor).isEmpty()
                && !feetState.getFluidState().isStill()
                && client.world.isChunkLoaded(feet);
    }

    private static boolean isWanted(Block b) {
        return switch (targetIndex) {
            case 0 -> b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE;
            case 1 -> b == Blocks.REDSTONE_ORE || b == Blocks.DEEPSLATE_REDSTONE_ORE;
            case 2 -> b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE;
            case 3 -> b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE;
            default -> b == Blocks.ANCIENT_DEBRIS;
        };
    }

    private static void aimAt(MinecraftClient client, Vec3d point) {
        Vec3d eye = client.player.getEyePos();
        Vec3d delta = point.subtract(eye);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float)(MathHelper.atan2(delta.z, delta.x) * 180.0 / Math.PI) - 90.0F;
        float pitch = (float)(-(MathHelper.atan2(delta.y, horizontal) * 180.0 / Math.PI));
        client.player.setYaw(yaw);
        client.player.setPitch(MathHelper.clamp(pitch, -90.0F, 90.0F));
    }
}
