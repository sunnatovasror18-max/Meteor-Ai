package dev.autofarm;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class AutoFarmScreen extends Screen {
    public AutoFarmScreen() { super(Text.literal("Auto Farm - Enter")); }

    @Override protected void init() {
        int x = width / 2 - 125;
        int y = height / 2 - 85;
        addDrawableChild(ButtonWidget.builder(toggleLabel("Auto Farm", AutoFarmClient.autoFarm), b -> {
            AutoFarmClient.autoFarm = !AutoFarmClient.autoFarm;
            b.setMessage(toggleLabel("Auto Farm", AutoFarmClient.autoFarm));
            if (!AutoFarmClient.autoFarm) {
                AutoFarmClient.targetBlock = null;
                if (client != null) { client.options.forwardKey.setPressed(false); client.options.jumpKey.setPressed(false); }
            }
        }).dimensions(x, y, 250, 20).build());

        addDrawableChild(ButtonWidget.builder(toggleLabel("Auto Clicker", AutoFarmClient.autoClicker), b -> {
            AutoFarmClient.autoClicker = !AutoFarmClient.autoClicker;
            b.setMessage(toggleLabel("Auto Clicker", AutoFarmClient.autoClicker));
        }).dimensions(x, y + 27, 250, 20).build());

        addDrawableChild(new SliderWidget(x, y + 54, 250, 20,
                Text.literal("CPS: " + AutoFarmClient.cps), (AutoFarmClient.cps - 5) / 35.0) {
            @Override protected void updateMessage() { setMessage(Text.literal("CPS: " + AutoFarmClient.cps)); }
            @Override protected void applyValue() {
                AutoFarmClient.cps = 5 + (int)Math.round(value * 35.0);
                AutoFarmClient.cps = Math.max(5, Math.min(40, AutoFarmClient.cps));
            }
        });

        addDrawableChild(ButtonWidget.builder(Text.literal("Ore: " + AutoFarmClient.TARGETS[AutoFarmClient.targetIndex]), b -> {
            AutoFarmClient.targetIndex = (AutoFarmClient.targetIndex + 1) % AutoFarmClient.TARGETS.length;
            AutoFarmClient.targetBlock = null;
            b.setMessage(Text.literal("Ore: " + AutoFarmClient.TARGETS[AutoFarmClient.targetIndex]));
        }).dimensions(x, y + 81, 250, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close()).dimensions(x, y + 108, 250, 20).build());
    }

    private static Text toggleLabel(String name, boolean enabled) {
        return Text.literal(name + ": " + (enabled ? "ON" : "OFF"));
    }

    @Override public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, height / 2 - 112, 0xFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Status: " + AutoFarmClient.status), width / 2, height / 2 + 54, 0xFFFF55);
        context.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Target scan radius: 16 blocks"), width / 2, height / 2 + 67, 0xAAAAAA);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override public boolean shouldPause() { return false; }
    @Override public void close() {
        if (client != null) {
            client.options.attackKey.setPressed(false);
            client.options.forwardKey.setPressed(false);
            client.options.jumpKey.setPressed(false);
            client.setScreen(null);
        }
    }
}
